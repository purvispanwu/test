# HackBar
Firefox and Google Chrome Extension of HackBar without license

## Firefox
[https://addons.mozilla.org/fr/firefox/addon/hackbar-free/](https://addons.mozilla.org/fr/firefox/addon/hackbar-free/)
